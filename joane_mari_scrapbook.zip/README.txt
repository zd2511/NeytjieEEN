JOANÉ MARI COCKERAN — ONS KLEIN WONDER

Gebore: 13 November 2025
Wagwoord: Vol Liefde

Die album is in kalendermaande gerangskik van November 2025 tot Oktober 2026.
Foto-datums is uit die datum in die lêernaam gelees. 73 foto's het 'n herkenbare datum.
2 Snapchat-foto's het nie 'n herkenbare datum in die lêernaam of EXIF-metadata gehad nie en is apart gehou.
Elke maand wys hoogstens ses hoof-foto's. Foto's bo die ses-per-maand-limiet is onder "Nog klein herinneringe" bewaar, met hul maand en datum.
Oop foto-plekke kan later op 'n toestel gevul word.

BELANGRIK OOR DEEL:
Die vooraf bygevoegde foto's is deel van die webwerf-lêers. As jy die hele webwerf op 'n webhost plaas, kan familie die ingeslote foto's sien.
Foto's wat later deur die leë plekke opgelaai word, word tans net in daardie toestel se blaaier gestoor; dit sinkroniseer NIE outomaties met familie se toestelle nie.
Die wagwoord is 'n eenvoudige front-end skerm, nie sterk sekuriteit nie. Vir private familie-deel moet die webwerf op 'n hosting-platform met gedeelde databasis/foto-berging en regte toegangbeheer geplaas word.
